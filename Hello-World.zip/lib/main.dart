import 'package:flutter/material.dart';

void main() => runApp(SmartUnitConverterApp());

class SmartUnitConverterApp extends StatefulWidget {
  @override
  _SmartUnitConverterAppState createState() => _SmartUnitConverterAppState();
}

class _SmartUnitConverterAppState extends State<SmartUnitConverterApp> {
  bool isDarkTheme = true;

  void toggleTheme() {
    setState(() {
      isDarkTheme = !isDarkTheme;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Unit Converter',
      theme: isDarkTheme ? ThemeData.dark() : ThemeData.light(),
      debugShowCheckedModeBanner: false,
      home: UnitConverterHome(toggleTheme: toggleTheme),
    );
  }
}

class UnitConverterHome extends StatefulWidget {
  final VoidCallback toggleTheme;

  UnitConverterHome({required this.toggleTheme});

  @override
  _UnitConverterHomeState createState() => _UnitConverterHomeState();
}

class _UnitConverterHomeState extends State<UnitConverterHome>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<String> history = [];

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  void addToHistory(String entry) {
    setState(() {
      history.insert(0, entry);
      if (history.length > 5) history.removeLast();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Smart Unit Converter'),
        actions: [
          IconButton(
            icon: Icon(Icons.brightness_6),
            onPressed: widget.toggleTheme,
          )
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Length'),
            Tab(text: 'Weight'),
            Tab(text: 'Temp'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          ConverterTab(
            units: ['Meters', 'Feet'],
            convert: (v, f, t) => f == 'Meters' ? v * 3.28084 : v / 3.28084,
            addToHistory: addToHistory,
          ),
          ConverterTab(
            units: ['Kilograms', 'Pounds'],
            convert: (v, f, t) => f == 'Kilograms' ? v * 2.20462 : v / 2.20462,
            addToHistory: addToHistory,
          ),
          ConverterTab(
            units: ['Celsius', 'Fahrenheit'],
            convert: (v, f, t) =>
                f == 'Celsius' ? (v * 9 / 5) + 32 : (v - 32) * 5 / 9,
            addToHistory: addToHistory,
          ),
        ],
      ),
      bottomNavigationBar: history.isEmpty
          ? null
          : Container(
              color: Theme.of(context).scaffoldBackgroundColor,
              padding: EdgeInsets.all(12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Recent Conversions:',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  ...history.map((h) => Text('• $h')).toList(),
                ],
              ),
            ),
    );
  }
}

class ConverterTab extends StatefulWidget {
  final List<String> units;
  final double Function(double, String, String) convert;
  final Function(String) addToHistory;

  ConverterTab({
    required this.units,
    required this.convert,
    required this.addToHistory,
  });

  @override
  _ConverterTabState createState() => _ConverterTabState();
}

class _ConverterTabState extends State<ConverterTab> {
  late String fromUnit;
  late String toUnit;
  String result = '';
  TextEditingController inputController = TextEditingController();

  @override
  void initState() {
    fromUnit = widget.units[0];
    toUnit = widget.units[1];
    super.initState();
  }

  void calculate() {
    final input = double.tryParse(inputController.text);
    if (input != null) {
      final converted = widget.convert(input, fromUnit, toUnit);
      setState(() {
        result = '${converted.toStringAsFixed(2)} $toUnit';
      });
      widget.addToHistory(
          '$input $fromUnit → ${converted.toStringAsFixed(2)} $toUnit');
    } else {
      setState(() {
        result = 'Invalid input';
      });
    }
  }

  void swapUnits() {
    setState(() {
      final temp = fromUnit;
      fromUnit = toUnit;
      toUnit = temp;
      result = '';
      inputController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          TextField(
            controller: inputController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'Enter value',
              border: OutlineInputBorder(),
            ),
          ),
          SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                  child: _buildDropdown(
                      fromUnit, (val) => setState(() => fromUnit = val))),
              IconButton(
                icon: Icon(Icons.swap_horiz),
                onPressed: swapUnits,
              ),
              Expanded(
                  child: _buildDropdown(
                      toUnit, (val) => setState(() => toUnit = val))),
            ],
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: calculate,
            child: Text('Convert'),
          ),
          SizedBox(height: 20),
          Text(
            result,
            style: TextStyle(fontSize: 24, color: Colors.amber),
          ),
        ],
      ),
    );
  }

  DropdownButton<String> _buildDropdown(
      String current, ValueChanged<String> onChanged) {
    return DropdownButton<String>(
      value: current,
      isExpanded: true,
      items: widget.units.map((unit) {
        return DropdownMenuItem(value: unit, child: Text(unit));
      }).toList(),
      onChanged: (val) => onChanged(val ?? current),
    );
  }
}
